#ifndef GLOBAL_H
#define GLOBAL_H

#include "../cpu/types.h"
extern u32 free_mem_addr;
extern u32 global_id;
extern u32 memory_limit;

#endif // GLOBAL_H
