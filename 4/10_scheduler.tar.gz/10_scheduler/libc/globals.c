#include "../cpu/types.h"
#include "globals.h"
u32 free_mem_addr;
u32 global_id;
u32 memory_limit;
