#ifndef KEYBOARD_H
#define KEYBOARD_H
#include "../cpu/types.h"

void init_keyboard();

#endif
